<?php
require_once('controllers/Check.php');
$Checkclass = new Checkclass();
$Checkclass->Member();
?>
