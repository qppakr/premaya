<?php
include("controllers/Connect.php");
$txtID = $_POST["txtID"];
$txtFirstname = $_POST["txtFirstname"];
$txtLastname = $_POST["txtLastname"];
$txtNickname = $_POST["txtNickname"];
$txtPhone = $_POST["txtPhone"];
$txtLine = $_POST["txtLine"];
$txtFacebook = $_POST["txtFacebook"];
$txtIG = $_POST["txtIG"];
$txtAddress = $_POST["txtAddress"];
$selCountry = $_POST["selCountry"];
$txtPMC = $_POST["txtPMC"];
$mesSuccess = 'บันทึกข้อมูลสำเร็จ!';
$mesSame = 'กรุณาเปลี่ยนรหัส PMC ทุกครั้ง เมื่อทำการอัพเดตข้อมูลส่วนตัว.';
$mesError = 'เกิดข้อผิดพลาดขณะบันทึกข้อมูล, โปรดติดต่อผู้ดูแลระบบ.';

$strSQL = "SELECT * FROM account WHERE ID = '$txtID' ";
$objQuery = mysqli_query($con,$strSQL);
$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);

if($objResult["Membercode"] != ""){

  $cmdSQL = "UPDATE account SET Firstname='$txtFirstname' ,Lastname='$txtLastname' ,Nickname='$txtNickname' ,Phone='$txtPhone' ,LineID='$txtLine' ,Facebook='$txtFacebook' ,IG='$txtIG' ,Address='$txtAddress' ,County='$selCountry' WHERE ID = '$txtID'";
  $cmdQuery = mysqli_query($con,$cmdSQL);
  if($cmdQuery)
  {
    echo '<script language="JavaScript"> alert("' . $mesSuccess . '") </script>';
    echo "<script> window.location.href='PROFILE.php'; </script>";
    exit();
  }
  else
  {
    echo '<script language="JavaScript"> alert("' . $mesError . '") </script>';
    echo "<script> window.location.href='PROFILE.php'; </script>";
    exit();
  }
}

else {
  if($objResult["PMC"] != $txtPMC){
    $cmdSQL = "UPDATE account SET Firstname='$txtFirstname' ,Lastname='$txtLastname' ,Nickname='$txtNickname' ,Phone='$txtPhone' ,LineID='$txtLine' ,Facebook='$txtFacebook' ,IG='$txtIG' ,Address='$txtAddress' ,County='$selCountry' ,PMC='$txtPMC' WHERE ID = '$txtID'";
    $cmdQuery = mysqli_query($con,$cmdSQL);
    if($cmdQuery)
    {
      echo '<script language="JavaScript"> alert("' . $mesSuccess . '") </script>';
      echo "<script> window.location.href='PROFILE.php'; </script>";
      exit();
    }
    else
    {
      echo '<script language="JavaScript"> alert("' . $mesError . '") </script>';
      echo "<script> window.location.href='PROFILE.php'; </script>";
      exit();
    }
  }
  else {
    echo '<script language="JavaScript"> alert("' . $mesSame . '") </script>';
    echo "<script> window.location.href='PROFILE.php'; </script>";
    exit();
  }

}

mysqli_close($con);
?>
